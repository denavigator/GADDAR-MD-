# WhatsApp Action Notifier

This repository contains a simple Node.js script and a GitHub Actions workflow example that sends a WhatsApp message via Meta's **WhatsApp Cloud API** when the workflow runs.

## Files

- `send-whatsapp.js` — Node script that calls the WhatsApp Cloud API.
- `package.json` — Node dependencies and script.
- `.github/workflows/notify-whatsapp.yml` — Example workflow that runs on `push`.
- `.gitignore`
- `README.md`

## Setup

1. Create a Meta App and WhatsApp Cloud API phone number in [Facebook for Developers].  
2. Get your **Access Token** and **Phone Number ID** for the WhatsApp Cloud API.
3. Add the following **Repository Secrets** in your GitHub repo:
   - `WHATSAPP_TOKEN` — your WhatsApp Cloud API access token.
   - `WHATSAPP_PHONE_NUMBER_ID` — the phone number ID (not the human phone number).
   - `TO_PHONE_NUMBER` — recipient phone number in international format (e.g. 2567xxxxxxx).

## Test locally

1. Copy `.env.example` to `.env` and fill values (or export env vars).
2. Install dependencies: `npm install`
3. Run: `npm run send`

## GitHub Workflow

The included workflow demonstrates how to run the script on `push` using repository secrets.

