// send-whatsapp.js
// Usage: set env variables WHATSAPP_TOKEN, WHATSAPP_PHONE_NUMBER_ID, TO_PHONE_NUMBER, MESSAGE (optional)
// Example: MESSAGE="Hello from GitHub Action" node send-whatsapp.js

const fetch = require('node-fetch');
require('dotenv').config();

const token = process.env.WHATSAPP_TOKEN;
const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
const to = process.env.TO_PHONE_NUMBER;
const message = process.env.MESSAGE || `Hello! This is a notification from your GitHub repository (repo: ${process.env.GITHUB_REPOSITORY || 'unknown'}).`;

if (!token || !phoneNumberId || !to) {
  console.error('Missing required environment variables. Make sure WHATSAPP_TOKEN, WHATSAPP_PHONE_NUMBER_ID and TO_PHONE_NUMBER are set.');
  process.exit(1);
}

const url = `https://graph.facebook.com/v17.0/${phoneNumberId}/messages`;

async function sendText() {
  const body = {
    messaging_product: "whatsapp",
    to,
    type: "text",
    text: { body: message }
  };

  const res = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  });

  const data = await res.json();
  if (!res.ok) {
    console.error('Failed to send message:', res.status, data);
    process.exit(1);
  }
  console.log('Message sent successfully:', JSON.stringify(data));
}

sendText().catch(err => {
  console.error('Error:', err);
  process.exit(1);
});
