/**
 * A simple GitHub bot built with Probot.
 */
module.exports = (app) => {
  app.log.info("Bot loaded!");

  app.on("issues.opened", async (context) => {
    const issueComment = context.issue({
      body: "👋 Thanks for opening an issue! I'm a bot."
    });
    return context.octokit.issues.createComment(issueComment);
  });
};
