# GitHub Bot Starter (Probot)

## Setup
```bash
npm install
npm start
```

## What it does
- Responds to newly opened issues with a friendly bot message.
